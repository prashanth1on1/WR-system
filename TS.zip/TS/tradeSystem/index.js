var fs = require('fs');
var _ = require('underscore');

var tradeObj = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
var trades = tradeObj.trades;

trades.sort(function(x, y){
    if(x.Symbol != y.Symbol){
        return compare(x.Symbol, y.Symbol);
    }
    if(x.Action != y.Action){
        return compare(x.Action, y.Action);
    }
    return compare(x.TxnId, y.TxnId);
});

var eachBuyPrice = [];
var currentFruit = null;
for(var i=0; i<trades.length; i++){
    if(currentFruit != trades[i].Symbol){
        currentFruit = trades[i].Symbol;
        eachBuyPrice = [];
    }
    
    if(trades[i].Action == 'Buy'){
        for (var j=0; j<trades[i].Quantity;j++){
            eachBuyPrice.push(trades[i].Price);
            trades[i].pl = 0;
        }
    }else if(trades[i].Action == 'Sell'){
        console.log("Before slicing "+eachBuyPrice);
        //compute total buyin price of the sold quantity
        var buyPrice = 0;
        for(var k=0; k<trades[i].Quantity;k++){
            buyPrice = buyPrice+eachBuyPrice[k];
        }
        trades[i].pl = ((trades[i].Price * trades[i].Quantity) - buyPrice).toFixed(2);
        
        eachBuyPrice.splice(0,trades[i].Quantity);
        console.log("After slicing "+eachBuyPrice);
    }
}

function compare(x, y){
  if (x === y) {
    return 0;
  }
  return x > y ? 1 : -1;
}

fs.writeFile('sorted.json', JSON.stringify(trades), (err) => {
    if(err) throw err;
    console.log('Save successfull');
});