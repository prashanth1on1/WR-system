var tradesApp = angular.module("tradesApp",["ngRoute","ngResource","ui.grid","ui.grid.grouping"]);

tradesApp.controller('tradesController',['$scope','tradesService', function($scope, tradesService){   
    $scope.gridOptions = {
        treeRowHeaderAlwaysVisible: false,
        data: tradesService.getTrades(),
        columnDefs: [
            {name:'ID', field: 'TxnId'},
            {name:'Symbol', field:'Symbol',grouping: { groupPriority: 0 } },
            {name:'Action', field:'Action',grouping: { groupPriority: 1 }},
            {name:'Quantity', field:'Quantity'},
            {name:'Price', field:'Price'},
            {name:'Market Value', field:'MarketValue'},
            {name: 'P/L', field:'pl'}
        ],
        onRegisterApi: function( gridApi ) {
            $scope.gridApi = gridApi;
            $scope.gridApi.grid.registerDataChangeCallback(function() {
                $scope.gridApi.treeBase.expandAllRows();
            });
        }
    };
    
    $scope.expandAll = function(){
        $scope.gridApi.treeBase.expandAllRows();
    };

    $scope.toggleRow = function( rowNum ){
        $scope.gridApi.treeBase.toggleRowTreeState($scope.gridApi.grid.renderContainers.body.visibleRowCache[rowNum]);
    };
}]);

tradesApp.service('tradesService', function($resource){
   var trades = [];
   this.getTrades = function(){
       var tradesAPI = $resource("http://localhost:6065/trades", {},{get: {method:"GET",isArray:true}});
       tradesAPI.get().$promise.then(function(result){
           angular.forEach(result, function (item) {
              trades.push(item);
              console.log(trades);
           });
       });           
       return trades;
          
       
    }
       
});