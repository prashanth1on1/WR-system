tradesApp.config(function($routeProvider){
    $routeProvider
        .when("/",
            {
                templateUrl : "trades.htm",
                controller  : "tradesController"    
            }
        
        )    
});